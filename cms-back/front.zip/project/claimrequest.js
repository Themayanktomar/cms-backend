function searchMember() {
    var memberId = document.getElementById("memberId").value;
    // Assuming you're using fetch for API calls
    fetch(`http://localhost:8080/members/getById/${memberId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Populate form fields with fetched data
            document.getElementById("fName").value = data.firstName;
            document.getElementById("LName").value = data.lastName;
            document.getElementById("requestDate").value = data.dateOfBirth;
            document.getElementById("maxClaimAmount").value = data.maxClaimAmount;
            document.getElementById("nomineeCount").value = data.nomineeCount;

            // Populate other fields as needed
            
            // Optional: Disable the Member ID field after fetching data
            document.getElementById("memberId").disabled = true;
        })
        .catch(error => {
            console.error('There was a problem with your fetch operation:', error);
        });
}
