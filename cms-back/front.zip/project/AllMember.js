document.addEventListener('DOMContentLoaded', function () {
    getAllMembers(); // Call the function to fetch all members when the page loads
});

async function getAllMembers() {
    try {
        const response = await fetch('http://localhost:8080/members/getAllMember');
        const data = await response.json();
        populateMemberTable(data); // Call the function to populate the member table with the fetched data
    } catch (error) {
        console.error('Error fetching all members:', error);
    }
}

function populateMemberTable(memberData) {
    const memberTableBody = document.getElementById('memberData');
    memberTableBody.innerHTML = ''; // Clear existing data

    memberData.forEach(member => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${member.memberId}</td>
            <td>${member.firstName}</td>
            <td>${member.lastName}</td>
            <td>${member.dateOfBirth}</td>
            <td>${member.address}</td>
            <td>${member.contactNo}</td>
            <td>${member.email}</td>
            <td>${member.gender}</td>
            <td>${member.nomineeCount}</td>
            <td>${member.insuranceType}</td>
            <td>${member.maxClaimAmount}</td>
            <td><button onclick="editMember('${member.memberId}')">Edit</button></td>
        `;
        memberTableBody.appendChild(row);
    });
}

async function editMember(memberId) {
    try {
        const response = await fetch(`http://localhost:8080/members/getById/${memberId}`);
        const data = await response.json();
        
        // Populate form fields with member data
        document.getElementById('Name').value = data.firstName;
        document.getElementById('LName').value = data.lastName;
        document.getElementById('birthday').value = data.dateOfBirth;
        document.getElementById('phone').value = data.contactNo;
        document.getElementById('Add').value = data.address;
        document.getElementById('Email').value = data.email;
        document.getElementById('gender').value = data.gender;
        document.getElementById('insurance-type').value = data.insuranceType;
        document.getElementById('insurance-amount').value = data.maxClaimAmount;
        document.getElementById('nominee-count').value = data.nomineeCount;

        // Show the form
        document.getElementById('updateForm').style.display = 'block';
    } catch (error) {
        console.error('Error fetching member by ID:', error);
    }
}

document.getElementById('updateForm').addEventListener('submit', async function (event) {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(this);
    const memberId = formData.get('memberId');

    try {
        const response = await fetch(`http://localhost:8080/members/update/${memberId}`, {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            console.log('Member updated successfully.');
            // Redirect or perform any other action upon successful update
        } else {
            console.error('Failed to update member:', response.statusText);
        }
    } catch (error) {
        console.error('Error updating member:', error);
    }
});


