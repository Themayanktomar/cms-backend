document.addEventListener('DOMContentLoaded', function () {
    // Select the form
    const form = document.getElementById('loginForm');

    // Add submit event listener to the form
    form.addEventListener('submit', function (event) {
        // Prevent the default form submission behavior
        event.preventDefault();

        // Get the values from the input fields
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Prepare the request body
        const body = JSON.stringify({
            adminId: username,
            password: password
        });

        // Make a POST request to the API endpoint
        fetch('http://localhost:8080/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: body
        })
        .then(response => {
            // Check if the response is successful
            if (response.ok) {
                // Redirect to dashboard.html or handle success accordingly
                window.location.href = 'dashboard.html';
            } else {
                // Handle error response
                console.error('Login failed');
            }
        })
        .catch(error => {
            // Handle network errors
            console.error('Network error:', error);
        });
    });
});
