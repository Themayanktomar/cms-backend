
async function updateInsuredAmount() {
    const insuranceType = document.getElementById("insurance-type").value;
    let insuredAmount = 0;
    let claimAmount = 0;

    try {
        const response = await fetch(`http://localhost:8080/members/getInsuranceAmount/${insuranceType}`);
        const data = await response.json();
        insuredAmount = parseFloat(data); 
        switch (insuranceType) {
            case "LIFE_INSURANCE":
                claimAmount = insuredAmount * 1.00;
                break;
            case "HOME_INSURANCE":
                claimAmount = insuredAmount * 0.91; 
                break;
            case "CAR_INSURANCE":
                claimAmount = insuredAmount * 0.80; 
                break;
            default:
                claimAmount = 0;
                break;
        }
    } catch (error) {
        console.error("Error fetching insured amount:", error);
        insuredAmount = 0; 
        claimAmount = 0;
    }

    document.getElementById("insured-amount").value = insuredAmount;
    document.getElementById("max-claim-amount").value = claimAmount;
}


async function registerMember(event) {
    event.preventDefault(); // Prevent the default form submission

    // Collect form data
    const formData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        dateOfBirth: document.getElementById('dateOfBirth').value,
        address: document.getElementById('address').value,
        contactNo: document.getElementById('contactNo').value,
        email: document.getElementById('email').value,
        gender: document.getElementById('gender').value,
        nomineeCount: document.getElementById('nomineeCount').value,
        insuranceType: document.getElementById('insuranceType').value
    };

    try {
        // Make API request to register the member
        const response = await fetch('http://localhost:8080/members/createMember', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        const data = await response.json();
        console.log('Member registered successfully:', data);

        // Optionally, you can reset the form here
        document.getElementById('update').reset();
    } catch (error) {
        console.error('Error registering member:', error);
    }
}